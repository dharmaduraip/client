
<?php

///is Europe’s 1st Super app of multi-services like ride-hailing, food delivery, grocery delivery, cashless payment solution, booking appointments with doctors, dentists, general physicians, advocates, accountants, reserving and booking services like mechanic , plumber, electrician and many other on-demand services all in one app.EasySuperapp is not just an app for multi-services but also has a social mission to improve people's lives. How? By helping each other and charging fair service charges.By downloading the application and using EasySuperapp's services, not only will you be helped in doing your daily business ... but you will also help EasySuperapp partners in reaching their dreams and their families, and be part of the mission to improve the standard of living of the people!




return array (

  "your_browser_does_not_support_the_video_tag"=>"Your browser does not support the video tag.",
  "making_life_easier_for_you"=>"making life easier for you",
  "home_content"=>"is Ethiopia 1st Super app of multi-services like ride-hailing, food delivery, grocery delivery, cashless payment solution, booking appointments with doctors, dentists, general physicians, advocates, accountants, reserving and booking services like mechanic , plumber, electrician and many other on-demand services all in one app.",
  "home_content1"=>" is not just an app for multi-services but also has a social mission to improve people's lives. How? By helping each other and charging fair service charges.By downloading the application and using",
  "home_content2"=>" services, not only will you be helped in doing your daily business ... but you will also help Addiplus partners in reaching their dreams and their families, and be part of the mission to improve the standard of living of the people",
  "one_app"=>"ONE APP",
  "for_all_your_needs"=>"FOR ALL YOUR NEEDS",

  "rides"=>"Rides",
  "deliveries"=>"Deliveries",
  "services"=>"Services",
  "taxi_ride"=>"Taxi Ride",
  "moto_rental"=>"Moto Rental",
  "movers"=>"Movers",
  "food"=>"Food",
  "grocery"=>"Grocery",
  "flower"=>"Flower",
  "electrician"=>"Electrician",
  "doctor"=>"Doctor",
  "plumber"=>"Plumber",
  "beauty_services"=>"Beauty Services",
  "dog_walking"=>"Dog Walking",
  "laundry"=>"Laundry",
  "house_cleaning"=>"House Cleaning",
  "carpenter"=>"Carpenter",
  "lawn_mowing"=>"Lawn Mowing",
  "cuddling"=>"Cuddling",
  "tutor"=>"Tutor",
  "massage"=>"Massage",
  "dj"=>"DJ",
  "baby_sitting"=>"Baby Sitting",
  "download"=>"Download",


  "today"=>"Today",
  "get_both_the_Android_and_iOS_apps_for_free.After_all,building_a_business_doesn’t_have_to_cost_you_a_bomb"=>"Get both the Android and iOS apps for free. After all, building a business doesn’t have to cost you a bomb!",
  "user_iOS_App_&_Android_App"=>"User iOS App & Android App",
  "download_on_the"=>"Download on the",

  "get_it_on"=>"Get it on",
  "shop_iOS_App & Android_App"=>"Shop  iOS App & Android App",
  "provider/driver_iOS_app & android_App"=>"Provider / Driver iOS App & Android App",
  "google_play"=>"Google Play",
  "iPad_iOS_App_&_tablet_android_app"=>"iPad  iOS App & Tablet Android App",

  "app_store"=>"App Store"

);

?>